
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">

            
            <div class="overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-100 mb-8">
                <div class="px-6 py-6">
                    <h3 class="text-lg font-semibold text-gray-900">
                        <?php echo e(__('Welcome')); ?>, <?php echo e(auth()->user()->name); ?>

                    </h3>

                    <p class="mt-1 text-sm text-gray-600">
                        <?php echo e(__('Here is an overview of your campaigns, credits, and billing status.')); ?>

                    </p>
                </div>
            </div>

            
            <div class="grid gap-6 md:grid-cols-3">

                
                <a href="<?php echo e(route('tenant.campaigns.index')); ?>"
                   class="block rounded-xl bg-white p-6 shadow-sm ring-1 ring-gray-100 hover:bg-gray-50 transition">
                    <h4 class="text-sm font-medium text-gray-500">
                        <?php echo e(__('Active Campaigns')); ?>

                    </h4>
                    <p class="mt-2 text-3xl font-bold text-gray-900">
                        <?php echo e($campaignsCount ?? 0); ?>

                    </p>
                    <p class="mt-1 text-sm text-indigo-600">
                        <?php echo e(__('View campaigns →')); ?>

                    </p>
                </a>

                
                <a href="<?php echo e(route('tenant.credits.index')); ?>"
                   class="block rounded-xl bg-white p-6 shadow-sm ring-1 ring-gray-100 hover:bg-gray-50 transition">
                    <h4 class="text-sm font-medium text-gray-500">
                        <?php echo e(__('Credits Balance')); ?>

                    </h4>
                    <p class="mt-2 text-3xl font-bold text-gray-900">
                        <?php echo e($creditsBalance ?? 0); ?>

                    </p>
                    <p class="mt-1 text-sm text-indigo-600">
                        <?php echo e(__('Manage credits →')); ?>

                    </p>
                </a>

                
                <a href="<?php echo e(route('tenant.billing.show')); ?>"
                   class="block rounded-xl bg-white p-6 shadow-sm ring-1 ring-gray-100 hover:bg-gray-50 transition">
                    <h4 class="text-sm font-medium text-gray-500">
                        <?php echo e(__('Subscription')); ?>

                    </h4>

                    <p class="mt-2 text-2xl font-semibold text-gray-900">
                        <?php
                            $plan = $subscription ?? null;
                        ?>

                        <?php if($plan === 'pro'): ?>
                            <?php echo e(__('Pro')); ?>

                        <?php elseif($plan === 'basic'): ?>
                            <?php echo e(__('Basic')); ?>

                        <?php elseif($plan): ?>
                            <?php echo e($plan); ?>

                        <?php else: ?>
                            <?php echo e(__('None')); ?>

                        <?php endif; ?>
                    </p>

                    <p class="mt-1 text-sm text-indigo-600">
                        <?php echo e(__('Manage billing →')); ?>

                    </p>
                </a>
            </div>

            
            <div class="mt-10">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">
                    <?php echo e(__('Quick actions')); ?>

                </h3>

                <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">

                    <a href="<?php echo e(route('tenant.campaigns.create')); ?>"
                       class="block rounded-lg border border-gray-200 bg-white px-4 py-3 text-sm font-medium text-gray-800 hover:bg-gray-50 shadow-sm">
                        <?php echo e(__('Create new campaign')); ?>

                    </a>

                    <a href="<?php echo e(route('tenant.api-keys.index')); ?>"
                       class="block rounded-lg border border-gray-200 bg-white px-4 py-3 text-sm font-medium text-gray-800 hover:bg-gray-50 shadow-sm">
                        <?php echo e(__('Manage API keys')); ?>

                    </a>

                    <a href="<?php echo e(route('tenant.billing.show')); ?>"
                       class="block rounded-lg border border-gray-200 bg-white px-4 py-3 text-sm font-medium text-gray-800 hover:bg-gray-50 shadow-sm">
                        <?php echo e(__('View billing settings')); ?>

                    </a>

                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/tenant/dashboard.blade.php ENDPATH**/ ?>