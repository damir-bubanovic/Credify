
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Admin dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">

            
            <?php if(session('status')): ?>
                <div class="mb-6 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            
            <div class="mb-8 grid gap-6 md:grid-cols-3">
                <div class="rounded-xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
                    <div class="text-sm font-medium text-gray-500">
                        <?php echo e(__('Total tenants')); ?>

                    </div>
                    <div class="mt-2 text-3xl font-bold text-gray-900">
                        <?php echo e($cards['tenants']); ?>

                    </div>
                </div>

                <div class="rounded-xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
                    <div class="text-sm font-medium text-gray-500">
                        <?php echo e(__('Subscribed tenants')); ?>

                    </div>
                    <div class="mt-2 text-3xl font-bold text-gray-900">
                        <?php echo e($cards['subscribed']); ?>

                    </div>
                </div>

                <div class="rounded-xl bg-white p-6 shadow-sm ring-1 ring-gray-100">
                    <div class="text-sm font-medium text-gray-500">
                        <?php echo e(__('Total credits across tenants')); ?>

                    </div>
                    <div class="mt-2 text-3xl font-bold text-gray-900">
                        <?php echo e(number_format((int) $cards['credits_sum'])); ?>

                    </div>
                </div>
            </div>

            
            <div class="overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-100">
                <div class="flex items-center justify-between border-b border-gray-100 px-6 py-4">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900">
                            <?php echo e(__('Recent tenants')); ?>

                        </h3>
                        <p class="mt-1 text-sm text-gray-500">
                            <?php echo e(__('Latest tenants created, with primary domain, plan, and credit balance.')); ?>

                        </p>
                    </div>

                    <a
                        href="<?php echo e(route('admin.tenants.index')); ?>"
                        class="text-sm font-medium text-indigo-600 hover:text-indigo-500"
                    >
                        <?php echo e(__('View all tenants →')); ?>

                    </a>
                </div>

                <div class="px-6 py-4">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200 text-sm">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-2 text-left font-medium text-gray-500">
                                        <?php echo e(__('ID')); ?>

                                    </th>
                                    <th class="px-4 py-2 text-left font-medium text-gray-500">
                                        <?php echo e(__('Primary domain')); ?>

                                    </th>
                                    <th class="px-4 py-2 text-left font-medium text-gray-500">
                                        <?php echo e(__('Created')); ?>

                                    </th>
                                    <th class="px-4 py-2 text-left font-medium text-gray-500">
                                        <?php echo e(__('Plan')); ?>

                                    </th>
                                    <th class="px-4 py-2 text-right font-medium text-gray-500">
                                        <?php echo e(__('Credits')); ?>

                                    </th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100 bg-white">
                                <?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $domain = optional($t->domains->first())->domain;
                                    ?>
                                    <tr>
                                        <td class="px-4 py-3 text-gray-900">
                                            <a
                                                href="<?php echo e(route('admin.tenants.show', $t)); ?>"
                                                class="font-medium text-indigo-600 hover:text-indigo-500"
                                            >
                                                <?php echo e($t->id); ?>

                                            </a>
                                        </td>
                                        <td class="px-4 py-3">
                                            <?php if($domain): ?>
                                                <a
                                                    href="http://<?php echo e($domain); ?>"
                                                    target="_blank"
                                                    class="text-indigo-600 hover:text-indigo-500"
                                                >
                                                    <?php echo e($domain); ?>

                                                </a>
                                            <?php else: ?>
                                                <span class="text-gray-400">—</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-4 py-3 text-gray-500">
                                            <?php echo e($t->created_at); ?>

                                        </td>
                                        <td class="px-4 py-3 text-gray-700">
                                            <?php echo e($t->plan ?? '—'); ?>

                                        </td>
                                        <td class="px-4 py-3 text-right text-gray-900">
                                            <?php echo e(number_format((int) $t->credit_balance)); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="px-4 py-4 text-center text-sm text-gray-500">
                                            <?php echo e(__('No tenants yet.')); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            
            <div class="mt-8 overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-100">
                <div class="border-b border-gray-100 px-6 py-4">
                    <h3 class="text-lg font-semibold text-gray-900">
                        <?php echo e(__('Latest credit transactions')); ?>

                    </h3>
                    <p class="mt-1 text-sm text-gray-500">
                        <?php echo e(__('Recent changes to tenant credit balances.')); ?>

                    </p>
                </div>

                <div class="px-6 py-4">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200 text-sm">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-2 text-left font-medium text-gray-500">
                                        <?php echo e(__('Tenant')); ?>

                                    </th>
                                    <th class="px-4 py-2 text-left font-medium text-gray-500">
                                        <?php echo e(__('Type')); ?>

                                    </th>
                                    <th class="px-4 py-2 text-right font-medium text-gray-500">
                                        <?php echo e(__('Amount')); ?>

                                    </th>
                                    <th class="px-4 py-2 text-left font-medium text-gray-500">
                                        <?php echo e(__('Reason')); ?>

                                    </th>
                                    <th class="px-4 py-2 text-left font-medium text-gray-500">
                                        <?php echo e(__('At')); ?>

                                    </th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100 bg-white">
                                <?php $__empty_1 = true; $__currentLoopData = $ledger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $delta  = (int) $row->delta;
                                        $amount = abs($delta);
                                        $sign   = $delta >= 0 ? '+' : '-';
                                        $type   = $delta >= 0 ? __('Credit') : __('Debit');
                                    ?>
                                    <tr>
                                        <td class="px-4 py-3 text-gray-900">
                                            <?php echo e($row->tenant_id); ?>

                                        </td>
                                        <td class="px-4 py-3">
                                            <span class="inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium
                                                <?php if($delta >= 0): ?>
                                                    border-green-200 bg-green-50 text-green-700
                                                <?php else: ?>
                                                    border-red-200 bg-red-50 text-red-700
                                                <?php endif; ?>
                                            ">
                                                <?php echo e($type); ?>

                                            </span>
                                        </td>
                                        <td class="px-4 py-3 text-right font-semibold
                                            <?php if($delta >= 0): ?> text-green-700 <?php else: ?> text-red-700 <?php endif; ?>
                                        ">
                                            <?php echo e($sign); ?><?php echo e(number_format($amount)); ?>

                                        </td>
                                        <td class="px-4 py-3 text-gray-700">
                                            <?php echo e($row->reason ?? '—'); ?>

                                        </td>
                                        <td class="px-4 py-3 text-gray-500">
                                            <?php echo e($row->created_at); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="px-4 py-4 text-center text-sm text-gray-500">
                                            <?php echo e(__('No transactions found.')); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>