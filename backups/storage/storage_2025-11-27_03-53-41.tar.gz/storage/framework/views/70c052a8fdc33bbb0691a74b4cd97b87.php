
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Credits')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="mx-auto max-w-5xl sm:px-6 lg:px-8">

            <?php if(session('status')): ?>
                <div class="mb-6 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            
            <div class="overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-100">
                <div class="border-b border-gray-100 px-6 py-4 flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900">
                            <?php echo e(__('Credit balance & settings')); ?>

                        </h3>
                        <p class="mt-1 text-sm text-gray-500">
                            <?php echo e(__('Configure low-balance alerts and auto top-up behaviour.')); ?>

                        </p>
                    </div>
                </div>

                <div class="px-6 py-6 grid gap-6 lg:grid-cols-3">
                    
                    <div class="lg:col-span-1">
                        <div class="rounded-lg bg-gray-50 px-4 py-5 text-center">
                            <div class="text-sm font-medium text-gray-500">
                                <?php echo e(__('Current balance')); ?>

                            </div>
                            <div class="mt-2 text-4xl font-bold text-gray-900">
                                <?php echo e(number_format($balance->balance, 0)); ?>

                            </div>
                        </div>
                    </div>

                    
                    <div class="lg:col-span-2">
                        <form
                            method="POST"
                            action="<?php echo e(route('tenant.credits.settings')); ?>"
                            class="space-y-4"
                        >
                            <?php echo csrf_field(); ?>

                            <div class="grid gap-4 sm:grid-cols-2">
                                <div>
                                    <label
                                        for="low_threshold"
                                        class="block text-sm font-medium text-gray-700"
                                    >
                                        <?php echo e(__('Low threshold')); ?>

                                    </label>
                                    <input
                                        id="low_threshold"
                                        name="low_threshold"
                                        type="number"
                                        min="0"
                                        value="<?php echo e(old('low_threshold', $balance->low_threshold)); ?>"
                                        class="mt-1 block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                    >
                                </div>

                                <div>
                                    <label
                                        for="topup_amount"
                                        class="block text-sm font-medium text-gray-700"
                                    >
                                        <?php echo e(__('Top-up amount')); ?>

                                    </label>
                                    <input
                                        id="topup_amount"
                                        name="topup_amount"
                                        type="number"
                                        min="0"
                                        value="<?php echo e(old('topup_amount', $balance->topup_amount)); ?>"
                                        class="mt-1 block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                    >
                                </div>
                            </div>

                            <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                                <div class="flex items-center">
                                    <input
                                        id="auto_topup_enabled"
                                        name="auto_topup_enabled"
                                        type="checkbox"
                                        value="1"
                                        <?php if(old('auto_topup_enabled', $balance->auto_topup_enabled)): echo 'checked'; endif; ?>
                                        class="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                    >
                                    <label
                                        for="auto_topup_enabled"
                                        class="ml-2 text-sm text-gray-700"
                                    >
                                        <?php echo e(__('Enable automatic top-up')); ?>

                                    </label>
                                </div>

                                <div class="sm:text-right">
                                    <label
                                        for="stripe_price_id"
                                        class="block text-sm font-medium text-gray-700"
                                    >
                                        <?php echo e(__('Stripe price ID for top-up')); ?>

                                    </label>
                                    <input
                                        id="stripe_price_id"
                                        name="stripe_price_id"
                                        type="text"
                                        value="<?php echo e(old('stripe_price_id', $balance->stripe_price_id)); ?>"
                                        class="mt-1 block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                        placeholder="price_xxx"
                                    >
                                </div>
                            </div>

                            <div class="pt-2">
                                <button
                                    type="submit"
                                    class="inline-flex items-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                                >
                                    <?php echo e(__('Save settings')); ?>

                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            
            <div class="mt-8 overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-100">
                <div class="border-b border-gray-100 px-6 py-4">
                    <h4 class="text-md font-semibold text-gray-900">
                        <?php echo e(__('Credit ledger')); ?>

                    </h4>
                    <p class="mt-1 text-sm text-gray-500">
                        <?php echo e(__('All credit movements over time.')); ?>

                    </p>
                </div>

                <div class="px-6 py-4">
                    <?php if($ledger->isEmpty()): ?>
                        <div class="rounded-lg border border-dashed border-gray-200 bg-gray-50 px-4 py-6 text-center text-sm text-gray-500">
                            <?php echo e(__('No ledger entries yet.')); ?>

                        </div>
                    <?php else: ?>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 text-sm">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-4 py-2 text-left font-medium text-gray-500">
                                            <?php echo e(__('Date')); ?>

                                        </th>
                                        <th class="px-4 py-2 text-left font-medium text-gray-500">
                                            <?php echo e(__('Reason')); ?>

                                        </th>
                                        <th class="px-4 py-2 text-left font-medium text-gray-500">
                                            <?php echo e(__('Δ')); ?>

                                        </th>
                                        <th class="px-4 py-2 text-left font-medium text-gray-500">
                                            <?php echo e(__('Balance after')); ?>

                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-100 bg-white">
                                    <?php $__currentLoopData = $ledger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-4 py-3 text-gray-500">
                                                <?php echo e($row->created_at); ?>

                                            </td>
                                            <td class="px-4 py-3 text-gray-700">
                                                <?php echo e($row->reason); ?>

                                            </td>
                                            <td class="px-4 py-3">
                                                <span class="font-semibold
                                                    <?php if($row->delta >= 0): ?> text-green-600 <?php else: ?> text-red-600 <?php endif; ?>
                                                ">
                                                    <?php echo e($row->delta); ?>

                                                </span>
                                            </td>
                                            <td class="px-4 py-3 text-gray-700">
                                                <?php echo e($row->balance_after); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="mt-4">
                            <?php echo e($ledger->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <div class="border-t border-gray-100 bg-gray-50 px-6 py-4">
                    <a
                        href="<?php echo e(route('dashboard')); ?>"
                        class="text-sm font-medium text-gray-500 hover:text-gray-700"
                    >
                        ← <?php echo e(__('Back to dashboard')); ?>

                    </a>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/tenant/credits/index.blade.php ENDPATH**/ ?>