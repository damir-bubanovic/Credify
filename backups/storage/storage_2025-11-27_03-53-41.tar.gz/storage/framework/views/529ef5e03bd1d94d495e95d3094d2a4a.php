
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Billing')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="mx-auto max-w-4xl sm:px-6 lg:px-8">

            <?php if(session('status')): ?>
                <div class="mb-6 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <div class="overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-100">
                
                <div class="border-b border-gray-100 px-6 py-4">
                    <h3 class="text-lg font-semibold text-gray-900">
                        <?php echo e(__('Subscription')); ?>

                    </h3>
                    <p class="mt-1 text-sm text-gray-500">
                        <?php echo e(__('Manage your plan and access the Stripe billing portal.')); ?>

                    </p>
                </div>

                <?php if($state['subscribed']): ?>
                    
                    <?php
                        // $state['plan'] is the Stripe price ID.
                        $planId   = $state['plan'] ?? null;
                        $planName = $planId;

                        if ($planId === ($priceBasic ?? null)) {
                            $planName = __('Basic');
                        } elseif ($planId === ($pricePro ?? null)) {
                            $planName = __('Pro');
                        } elseif ($planId === null) {
                            $planName = __('Active subscription');
                        }
                    ?>

                    <div class="px-6 py-6">
                        <div class="rounded-lg bg-gray-50 px-4 py-5">
                            <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                                <div>
                                    <p class="text-sm font-medium text-gray-500">
                                        <?php echo e(__('Current plan')); ?>

                                    </p>
                                    <p class="mt-1 text-xl font-semibold text-gray-900">
                                        <?php echo e($planName); ?>

                                    </p>
                                    <?php if(!empty($state['renews_at'])): ?>
                                        <p class="mt-1 text-sm text-gray-500">
                                            <?php echo e(__('Renews at:')); ?> <?php echo e($state['renews_at']); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>

                                <div class="flex flex-wrap gap-2">
                                    <a
                                        href="<?php echo e(route('tenant.billing.portal')); ?>"
                                        class="inline-flex items-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                                    >
                                        <?php echo e(__('Manage subscription')); ?>

                                    </a>

                                    <a
                                        href="<?php echo e(route('tenant.dashboard')); ?>"
                                        class="inline-flex items-center rounded-md border border-gray-200 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                                    >
                                        <?php echo e(__('Back to dashboard')); ?>

                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    
                    <div class="px-6 py-6">
                        <div class="mb-6 rounded-lg bg-yellow-50 px-4 py-3 text-sm text-yellow-800 border border-yellow-200">
                            <?php echo e(__('You do not have an active subscription. Choose a plan to get started.')); ?>

                        </div>

                        <div class="grid gap-6 md:grid-cols-2">
                            
                            <div class="flex flex-col justify-between rounded-lg border border-gray-200 bg-gray-50 px-4 py-5">
                                <div>
                                    <h4 class="text-lg font-semibold text-gray-900">
                                        <?php echo e(__('Basic')); ?>

                                    </h4>
                                    <p class="mt-1 text-sm text-gray-500">
                                        <?php echo e(__('Good for trying out the platform or smaller workloads.')); ?>

                                    </p>
                                </div>

                                <form
                                    method="POST"
                                    action="<?php echo e(route('tenant.billing.checkout', $priceBasic)); ?>"
                                    class="mt-4"
                                >
                                    <?php echo csrf_field(); ?>
                                    <button
                                        type="submit"
                                        class="inline-flex w-full justify-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                                    >
                                        <?php echo e(__('Subscribe Basic')); ?>

                                    </button>
                                </form>
                            </div>

                            
                            <div class="flex flex-col justify-between rounded-lg border border-gray-200 bg-gray-50 px-4 py-5">
                                <div>
                                    <h4 class="text-lg font-semibold text-gray-900">
                                        <?php echo e(__('Pro')); ?>

                                    </h4>
                                    <p class="mt-1 text-sm text-gray-500">
                                        <?php echo e(__('For growing usage and production workloads.')); ?>

                                    </p>
                                </div>

                                <form
                                    method="POST"
                                    action="<?php echo e(route('tenant.billing.checkout', $pricePro)); ?>"
                                    class="mt-4"
                                >
                                    <?php echo csrf_field(); ?>
                                    <button
                                        type="submit"
                                        class="inline-flex w-full justify-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                                    >
                                        <?php echo e(__('Subscribe Pro')); ?>

                                    </button>
                                </form>
                            </div>
                        </div>

                        <div class="mt-6">
                            <a
                                href="<?php echo e(route('tenant.dashboard')); ?>"
                                class="text-sm font-medium text-gray-500 hover:text-gray-700"
                            >
                                ← <?php echo e(__('Back to dashboard')); ?>

                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/tenant/billing/show.blade.php ENDPATH**/ ?>