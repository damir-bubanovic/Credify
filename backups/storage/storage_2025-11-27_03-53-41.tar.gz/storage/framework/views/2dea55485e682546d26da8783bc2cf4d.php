
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Tenants')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">

            <?php if(session('status')): ?>
                <div class="mb-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            
            <div class="mb-4 overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-100">
                <div class="border-b border-gray-100 px-6 py-4">
                    <h3 class="text-lg font-semibold text-gray-900">
                        <?php echo e(__('Filter tenants')); ?>

                    </h3>
                </div>

                <div class="px-6 py-4">
                    <form class="flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-4" method="GET">
                        <div>
                            <label for="status" class="block text-xs font-medium text-gray-500 mb-1">
                                <?php echo e(__('Status')); ?>

                            </label>
                            <select
                                id="status"
                                name="status"
                                class="block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                            >
                                <option value=""><?php echo e(__('All')); ?></option>
                                <option value="active" <?php if(request('status') === 'active'): echo 'selected'; endif; ?>><?php echo e(__('Active')); ?></option>
                                <option value="suspended" <?php if(request('status') === 'suspended'): echo 'selected'; endif; ?>><?php echo e(__('Suspended')); ?></option>
                            </select>
                        </div>

                        <div class="flex items-center gap-2">
                            <input
                                type="checkbox"
                                id="only_trashed"
                                name="only_trashed"
                                value="1"
                                <?php if(request('only_trashed')): echo 'checked'; endif; ?>
                                class="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                            >
                            <label for="only_trashed" class="text-sm text-gray-700">
                                <?php echo e(__('Deleted')); ?>

                            </label>
                        </div>

                        <div class="sm:ml-auto">
                            <button
                                type="submit"
                                class="inline-flex items-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                            >
                                <?php echo e(__('Apply filters')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>

            
            <div class="overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-100">
                <div class="border-b border-gray-100 px-6 py-4">
                    <h3 class="text-lg font-semibold text-gray-900">
                        <?php echo e(__('Tenants')); ?>

                    </h3>
                </div>

                <div class="px-6 py-4">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200 text-sm">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-2 text-left font-medium text-gray-500">
                                        <?php echo e(__('ID')); ?>

                                    </th>
                                    <th class="px-4 py-2 text-left font-medium text-gray-500">
                                        <?php echo e(__('Domain')); ?>

                                    </th>
                                    <th class="px-4 py-2 text-left font-medium text-gray-500">
                                        <?php echo e(__('Status')); ?>

                                    </th>
                                    <th class="px-4 py-2 text-left font-medium text-gray-500">
                                        <?php echo e(__('Created')); ?>

                                    </th>
                                    <th class="px-4 py-2 text-right font-medium text-gray-500">
                                        <?php echo e(__('Actions')); ?>

                                    </th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100 bg-white">
                                <?php $__empty_1 = true; $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $domain = optional($t->domains->first())->domain;
                                        $status = $t->status ?? 'active';
                                    ?>
                                    <tr>
                                        <td class="px-4 py-3 text-gray-900">
                                            <a
                                                href="<?php echo e(route('admin.tenants.show', $t)); ?>"
                                                class="font-medium text-indigo-600 hover:text-indigo-500"
                                            >
                                                <?php echo e($t->id); ?>

                                            </a>
                                        </td>
                                        <td class="px-4 py-3 text-gray-700">
                                            <?php echo e($domain ?: '—'); ?>

                                        </td>
                                        <td class="px-4 py-3">
                                            <span class="inline-flex rounded-full px-2 py-0.5 text-xs font-medium
                                                <?php if($status === 'active'): ?>
                                                    bg-green-100 text-green-800
                                                <?php elseif($status === 'suspended'): ?>
                                                    bg-yellow-100 text-yellow-800
                                                <?php else: ?>
                                                    bg-gray-100 text-gray-800
                                                <?php endif; ?>
                                            ">
                                                <?php echo e(ucfirst($status)); ?>

                                            </span>
                                            <?php if(method_exists($t, 'trashed') && $t->trashed()): ?>
                                                <span class="ml-2 inline-flex rounded-full bg-red-50 px-2 py-0.5 text-xs font-medium text-red-700">
                                                    <?php echo e(__('Deleted')); ?>

                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-4 py-3 text-gray-500">
                                            <?php echo e($t->created_at); ?>

                                        </td>
                                        <td class="px-4 py-3 text-right whitespace-nowrap">
                                            <div class="flex justify-end gap-2">

                                                <a
                                                    href="<?php echo e(route('admin.tenants.show', $t)); ?>"
                                                    class="rounded-md border border-gray-200 px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50"
                                                >
                                                    <?php echo e(__('View')); ?>

                                                </a>

                                                <?php if(method_exists($t, 'trashed') && $t->trashed()): ?>
                                                    <form
                                                        method="POST"
                                                        action="<?php echo e(route('admin.tenants.restore', $t->id)); ?>"
                                                        class="inline-block"
                                                    >
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <button
                                                            type="submit"
                                                            class="rounded-md border border-green-200 px-3 py-1.5 text-xs font-medium text-green-700 hover:bg-green-50"
                                                        >
                                                            <?php echo e(__('Restore')); ?>

                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <?php if($status === 'active'): ?>
                                                        <form
                                                            method="POST"
                                                            action="<?php echo e(route('admin.tenants.suspend', $t)); ?>"
                                                            class="inline-block"
                                                        >
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PATCH'); ?>
                                                            <button
                                                                type="submit"
                                                                class="rounded-md border border-yellow-200 px-3 py-1.5 text-xs font-medium text-yellow-700 hover:bg-yellow-50"
                                                            >
                                                                <?php echo e(__('Suspend')); ?>

                                                            </button>
                                                        </form>
                                                    <?php else: ?>
                                                        <form
                                                            method="POST"
                                                            action="<?php echo e(route('admin.tenants.activate', $t)); ?>"
                                                            class="inline-block"
                                                        >
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PATCH'); ?>
                                                            <button
                                                                type="submit"
                                                                class="rounded-md border border-green-200 px-3 py-1.5 text-xs font-medium text-green-700 hover:bg-green-50"
                                                            >
                                                                <?php echo e(__('Activate')); ?>

                                                            </button>
                                                        </form>
                                                    <?php endif; ?>

                                                    <form
                                                        method="POST"
                                                        action="<?php echo e(route('admin.tenants.destroy', $t)); ?>"
                                                        class="inline-block"
                                                        onsubmit="return confirm('<?php echo e(__('Delete tenant?')); ?>');"
                                                    >
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button
                                                            type="submit"
                                                            class="rounded-md border border-red-200 px-3 py-1.5 text-xs font-medium text-red-700 hover:bg-red-50"
                                                        >
                                                            <?php echo e(__('Delete')); ?>

                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="px-4 py-4 text-center text-sm text-gray-500">
                                            <?php echo e(__('No tenants found.')); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-4">
                        <?php echo e($tenants->links()); ?>

                    </div>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/admin/tenants/index.blade.php ENDPATH**/ ?>