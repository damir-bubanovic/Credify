
<img
    src="/images/logo-final.png"
    alt="Credify logo"
    <?php echo e($attributes->merge([
        'class' => 'h-9 w-auto object-contain'
    ])); ?>

>
<?php /**PATH /var/www/html/resources/views/components/application-logo.blade.php ENDPATH**/ ?>