
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Billing')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="mx-auto max-w-4xl sm:px-6 lg:px-8">

            
            <?php if(request('success')): ?>
                <div class="mb-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
                    <?php echo e(__('Subscription created successfully.')); ?>

                </div>
            <?php endif; ?>

            <?php if(request('canceled')): ?>
                <div class="mb-4 rounded-lg border border-yellow-200 bg-yellow-50 px-4 py-3 text-sm text-yellow-800">
                    <?php echo e(__('Subscription flow was canceled.')); ?>

                </div>
            <?php endif; ?>

            <div class="overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-100">
                
                <div class="border-b border-gray-100 px-6 py-4">
                    <h3 class="text-lg font-semibold text-gray-900">
                        <?php echo e(__('Choose your plan')); ?>

                    </h3>
                    <p class="mt-1 text-sm text-gray-500">
                        <?php echo e(__('Select a subscription plan to get started. You can manage your subscription later in the customer portal.')); ?>

                    </p>
                </div>

                
                <div class="px-6 py-6">
                    <div class="grid gap-6 md:grid-cols-2">
                        
                        <div class="flex flex-col justify-between rounded-lg border border-gray-200 bg-gray-50 px-4 py-5">
                            <div>
                                <h4 class="text-lg font-semibold text-gray-900">
                                    <?php echo e(__('Basic')); ?>

                                </h4>
                                <p class="mt-1 text-sm text-gray-500">
                                    <?php echo e(__('Good for trying out the platform or smaller workloads.')); ?>

                                </p>
                            </div>

                            <form
                                method="POST"
                                action="<?php echo e(route('admin.billing.checkout', 'basic')); ?>"
                                class="mt-4"
                            >
                                <?php echo csrf_field(); ?>
                                <button
                                    type="submit"
                                    class="inline-flex w-full justify-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                                >
                                    <?php echo e(__('Subscribe Basic')); ?>

                                </button>
                            </form>
                        </div>

                        
                        <div class="flex flex-col justify-between rounded-lg border border-gray-200 bg-gray-50 px-4 py-5">
                            <div>
                                <h4 class="text-lg font-semibold text-gray-900">
                                    <?php echo e(__('Pro')); ?>

                                </h4>
                                <p class="mt-1 text-sm text-gray-500">
                                    <?php echo e(__('For growing usage and production workloads.')); ?>

                                </p>
                            </div>

                            <form
                                method="POST"
                                action="<?php echo e(route('admin.billing.checkout', 'pro')); ?>"
                                class="mt-4"
                            >
                                <?php echo csrf_field(); ?>
                                <button
                                    type="submit"
                                    class="inline-flex w-full justify-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                                >
                                    <?php echo e(__('Subscribe Pro')); ?>

                                </button>
                            </form>
                        </div>
                    </div>

                    
                    <div class="mt-6 flex items-center justify-between border-t border-gray-200 pt-4">
                        <p class="text-xs text-gray-500">
                            <?php echo e(__('Already subscribed? You can update payment details or cancel anytime in the billing portal.')); ?>

                        </p>

                        <a
                            href="<?php echo e(route('admin.billing.portal')); ?>"
                            class="text-sm font-medium text-indigo-600 hover:text-indigo-500"
                        >
                            <?php echo e(__('Manage billing')); ?> →
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/billing/show.blade.php ENDPATH**/ ?>