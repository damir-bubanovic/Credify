
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Tenant')); ?> #<?php echo e($tenant->id); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="mx-auto max-w-5xl sm:px-6 lg:px-8">

            <?php if(session('status')): ?>
                <div class="mb-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            
            <div class="overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-100 mb-8">
                <div class="border-b border-gray-100 px-6 py-4 flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900">
                            <?php echo e(__('Tenant details')); ?>

                        </h3>
                        <p class="mt-1 text-sm text-gray-500">
                            <?php echo e(__('Overview of tenant status, domains, plan and credits.')); ?>

                        </p>
                    </div>

                    <a
                        href="<?php echo e(route('admin.tenants.index')); ?>"
                        class="text-sm font-medium text-gray-500 hover:text-gray-700"
                    >
                        ← <?php echo e(__('Back to tenants')); ?>

                    </a>
                </div>

                <div class="px-6 py-6">
                    <?php
                        $status = $tenant->status ?? 'active';
                        $domains = $tenant->domains->pluck('domain')->join(', ') ?: '—';
                        $credits = number_format((int) $tenant->credit_balance);
                        $plan    = $tenant->plan ?? '—';
                    ?>

                    <dl class="grid gap-6 sm:grid-cols-2">
                        <div class="rounded-lg bg-gray-50 px-4 py-3">
                            <dt class="text-xs font-medium uppercase tracking-wide text-gray-500">
                                <?php echo e(__('Status')); ?>

                            </dt>
                            <dd class="mt-1 text-sm text-gray-900">
                                <span class="inline-flex rounded-full px-2 py-0.5 text-xs font-medium
                                    <?php if($status === 'active'): ?>
                                        bg-green-100 text-green-800
                                    <?php elseif($status === 'suspended'): ?>
                                        bg-yellow-100 text-yellow-800
                                    <?php else: ?>
                                        bg-gray-100 text-gray-800
                                    <?php endif; ?>
                                ">
                                    <?php echo e(ucfirst($status)); ?>

                                </span>
                            </dd>
                        </div>

                        <div class="rounded-lg bg-gray-50 px-4 py-3">
                            <dt class="text-xs font-medium uppercase tracking-wide text-gray-500">
                                <?php echo e(__('Plan')); ?>

                            </dt>
                            <dd class="mt-1 text-sm text-gray-900">
                                <?php echo e($plan); ?>

                            </dd>
                        </div>

                        <div class="rounded-lg bg-gray-50 px-4 py-3 sm:col-span-2">
                            <dt class="text-xs font-medium uppercase tracking-wide text-gray-500">
                                <?php echo e(__('Domains')); ?>

                            </dt>
                            <dd class="mt-1 text-sm text-gray-900">
                                <?php echo e($domains); ?>

                            </dd>
                        </div>

                        <div class="rounded-lg bg-gray-50 px-4 py-3">
                            <dt class="text-xs font-medium uppercase tracking-wide text-gray-500">
                                <?php echo e(__('Credits')); ?>

                            </dt>
                            <dd class="mt-1 text-sm text-gray-900">
                                <?php echo e($credits); ?>

                            </dd>
                        </div>

                        <div class="rounded-lg bg-gray-50 px-4 py-3">
                            <dt class="text-xs font-medium uppercase tracking-wide text-gray-500">
                                <?php echo e(__('Created at')); ?>

                            </dt>
                            <dd class="mt-1 text-sm text-gray-900">
                                <?php echo e($tenant->created_at); ?>

                            </dd>
                        </div>
                    </dl>
                </div>
            </div>

            
            <?php if($subscriptions->count()): ?>
                <div class="overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-100">
                    <div class="border-b border-gray-100 px-6 py-4">
                        <h3 class="text-lg font-semibold text-gray-900">
                            <?php echo e(__('Subscriptions')); ?>

                        </h3>
                        <p class="mt-1 text-sm text-gray-500">
                            <?php echo e(__('Stripe subscriptions associated with this tenant.')); ?>

                        </p>
                    </div>

                    <div class="px-6 py-4">
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 text-sm">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-4 py-2 text-left font-medium text-gray-500">
                                            <?php echo e(__('Name')); ?>

                                        </th>
                                        <th class="px-4 py-2 text-left font-medium text-gray-500">
                                            <?php echo e(__('Status')); ?>

                                        </th>
                                        <th class="px-4 py-2 text-left font-medium text-gray-500">
                                            <?php echo e(__('Price')); ?>

                                        </th>
                                        <th class="px-4 py-2 text-left font-medium text-gray-500">
                                            <?php echo e(__('Quantity')); ?>

                                        </th>
                                        <th class="px-4 py-2 text-left font-medium text-gray-500">
                                            <?php echo e(__('Created')); ?>

                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-100 bg-white">
                                    <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-4 py-3 text-gray-900">
                                                <?php echo e($s->name); ?>

                                            </td>
                                            <td class="px-4 py-3 text-gray-700">
                                                <?php echo e($s->stripe_status); ?>

                                            </td>
                                            <td class="px-4 py-3 font-mono text-xs text-gray-800">
                                                <?php echo e($s->stripe_price); ?>

                                            </td>
                                            <td class="px-4 py-3 text-gray-700">
                                                <?php echo e($s->quantity); ?>

                                            </td>
                                            <td class="px-4 py-3 text-gray-500">
                                                <?php echo e($s->created_at); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            
            <div class="mt-8">
                <a
                    href="<?php echo e(route('admin.tenants.index')); ?>"
                    class="text-sm font-medium text-gray-500 hover:text-gray-700"
                >
                    ← <?php echo e(__('Back to tenants')); ?>

                </a>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/admin/tenants/show.blade.php ENDPATH**/ ?>